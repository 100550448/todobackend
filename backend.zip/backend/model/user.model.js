import { usermodel } from "./user.schema.js";

export const createUser =async (user) =>{
    let newUser =await usermodel.create(user)
    return newUser
}

export const fetcheUsers =async (user) =>{
    let users =await usermodel.find()
     return users;
}

export const modifyUser =async(id ,data) =>{
   let newuser = await usermodel.findByIdAndUpdate(id, data, {new: true})
    return newuser;
}

export const removeUser =async(id) =>{
    await usermodel.findByIdAndUpdate(id)
     return
 }

