import mongoose from "mongoose";


const userSchema =  mongoose.Schema({
    name:{
        type: String,
        required : [true, 'Name must be required'],
        minlength : [2, 'Name must be 2 charactars at least'],
        maxlength : [10, 'Name must be 10 charactars at least']

    },

    email: {
        type: String,
        required: [true, 'Email is required'],
        minlength: [10, 'Email must be at least 10 characters long'],
        maxlength: [50, 'Email cannot exceed 50 characters'],
        unique: true,    // important
            
    },
    

    password:{
        type: String,
        required : [true, 'Password must be required'],
        minlength : [5, 'Name must be 5 charactars at least'],
        maxlength : [14 , 'Name must be 10 charactars at least']

    }
})

export const usermodel = mongoose.model('users', userSchema)