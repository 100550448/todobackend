import express from "express";
import { addUser, homepage, getUsers, updateUser, deleteUser } from "../controller/user.controller.js";

const Router = express.Router();

Router.get('/', homepage)
Router.post('/adduser', addUser)
Router.get('/getusers', getUsers)
// Router.put('/updateuser/:id', updateUser)
// Router.delete('/deleteuser/:id', deleteUser)
Router.post('/updateuser/:id', updateUser)
Router.post('/deleteuser/:id', deleteUser)





export default Router;