import mongoose from 'mongoose'

const url  = 'mongodb+srv://sahiljadhav:jadhav@cluster0.89vlgmg.mongodb.net/?appName=Cluster0'




export const connectDB = async() => {
await mongoose.connect(url)
console.log("connected to database");
}

// module.exports = connectDB;