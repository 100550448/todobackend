import {createUser, fetcheUsers, modifyUser, removeUser} from "../model/user.model.js"
import { usermodel } from "../model/user.schema.js"

export const homepage= (req, res) =>{
// res.send("Welcome to homepage")
res.render('index', {name: "Sona"})
}

export const addUser =async (req, res) =>{
    // const {name, email, password} = req.body;
    let user =await createUser(req.body)
    res.send("user created successfully", user)
}

export const getUsers =async (req, res) =>{
   const data =await fetcheUsers();
    // res.json({success:true, data:data})

    // res.render('users', {data: ['Golu', 'sahil', 'sagar', 'sona']})
    res.render('users', {data})


}
// export const updateUser =async (req, res) =>{
//     let user  =await modifyUser(req.params.id, req.body)
//  res.json({message: "User updated successfully" , user})
 
//  }


//for showing on browser display

export const updateUser = async (req, res) => {
  try {
      await usermodel.findByIdAndUpdate(req.params.id, req.body, { new: true });
      res.redirect("/getusers");  // 👈 redirect to UI
  } catch (error) {
      res.status(500).json({ message: error.message });
  }
};

export const deleteUser = async (req, res) => {
  try {
      await usermodel.findByIdAndDelete(req.params.id);
      res.redirect("/getusers");  // 👈 redirect to UI
  } catch (error) {
      res.status(500).json({ message: error.message });
  }
};

