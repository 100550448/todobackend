import express from 'express';
import Router from './routs/user.routs.js';
import { connectDB } from './utils/db.config.js';
import path from 'path';
import {fileURLToPath} from 'url'


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename)

const app = express() //instance of express
app.set('view engine', 'ejs'); // ejs engine
app.use(express.static(path.join(__dirname, 'public'))) //link stylesheet
app.use(express.json()) //middleware
app.use(express.urlencoded({ extended: true }));

app.use(Router) //router call
connectDB() //database

app.listen(3002, () =>{
    console.log("server is running on port 3002");
}) 







